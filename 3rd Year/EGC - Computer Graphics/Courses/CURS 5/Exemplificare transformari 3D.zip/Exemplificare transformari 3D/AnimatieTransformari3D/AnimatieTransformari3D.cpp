#include "AnimatieTransformari3D.h"

#include <vector>
#include <string>
#include <iostream>

#include <Core/Engine.h>
#include "Transform3D.h"

using namespace std;

const float step = 1.0f;

AnimatieTransformari3D::AnimatieTransformari3D()
{
}

AnimatieTransformari3D::~AnimatieTransformari3D()
{
}

void AnimatieTransformari3D::Init()
{
	polygonMode = GL_FILL;

	Mesh* mesh = new Mesh("box");
	mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
	meshes[mesh->GetMeshID()] = mesh;

	auto camera = GetSceneCamera();
	//camera->SetPositionAndRotation(glm::vec3(0, 4, 10), glm::quat(glm::vec3(-20 * TO_RADIANS, 0, 0)));
	camera->SetPositionAndRotation(glm::vec3(4, 4, 10), glm::quat(glm::vec3(-20 * TO_RADIANS, 0, 0)));
	
	camera->Update();

	
	// initializare tx, ty, tz (pasii de translatie)
	translateX = 0;
	translateY = 0;
	translateZ = 0;

	// initializare sx, sy, sz (factorii de scalare)
	scaleX = 1;
	scaleY = 1;
	scaleZ = 1;
	
	// initializare pasi de rotatie
	angularStepOX = 0;
	angularStepOY = 0;
	angularStepOZ = 0;

}

void AnimatieTransformari3D::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// setwza viewportul
	glViewport(0, 0, resolution.x, resolution.y);
}

void AnimatieTransformari3D::Update(float deltaTimeSeconds)
{

	modelMatrix = glm::mat4(1);
	
	modelMatrix *= Transform3D::Scale(scaleX, scaleY, scaleZ);
	modelMatrix *= Transform3D::RotateOX(angularStepOX);
	modelMatrix *= Transform3D::RotateOY(angularStepOY);
	modelMatrix *= Transform3D::RotateOZ(angularStepOZ);
	modelMatrix *= Transform3D::Translate(translateX, translateY, translateZ);
	RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);
}

void AnimatieTransformari3D::FrameEnd()
{
	DrawCoordinatSystem();
}

void AnimatieTransformari3D::OnInputUpdate(float deltaTime, int mods)
{//apelata la fiecare deltaTime secunde
	if (window->KeyHold(GLFW_KEY_1)) angularStepOX += step * deltaTime;
	if (window->KeyHold(GLFW_KEY_2)) angularStepOX -= step * deltaTime;
	if (window->KeyHold(GLFW_KEY_3)) angularStepOY += step * deltaTime;
	if (window->KeyHold(GLFW_KEY_4)) angularStepOY -= step * deltaTime;
	if (window->KeyHold(GLFW_KEY_5)) angularStepOZ += step * deltaTime;
	if (window->KeyHold(GLFW_KEY_6)) angularStepOZ -= step * deltaTime;
	if (window->KeyHold(GLFW_KEY_7)) scaleX += step * deltaTime;
	if (window->KeyHold(GLFW_KEY_8)) scaleX -= step * deltaTime;
	if (window->KeyHold(GLFW_KEY_9)) scaleY += step * deltaTime;
	if (window->KeyHold(GLFW_KEY_0)) scaleY -= step * deltaTime;
	if (window->KeyHold(GLFW_KEY_MINUS)) scaleZ -= step * deltaTime;
	if (window->KeyHold(GLFW_KEY_EQUAL)) scaleZ += step * deltaTime;
	if (window->KeyHold(GLFW_KEY_UP)) translateY += step * deltaTime;
	if (window->KeyHold(GLFW_KEY_DOWN)) translateY -= step * deltaTime;
	if (window->KeyHold(GLFW_KEY_LEFT)) translateX -= step * deltaTime;
	if (window->KeyHold(GLFW_KEY_RIGHT)) translateX += step * deltaTime;
	if (window->KeyHold(GLFW_KEY_PAGE_UP)) translateZ += step * deltaTime;
	if (window->KeyHold(GLFW_KEY_PAGE_DOWN)) translateZ -= step * deltaTime;
}



void AnimatieTransformari3D::OnKeyPress(int key, int mods)
{
	if (key == GLFW_KEY_SPACE)
	{
		//reseteaza toate variabilele
		angularStepOX = 0;
		angularStepOY = 0;
		angularStepOZ = 0;
		scaleX = 1;
		scaleY = 1;
		scaleZ = 1;
		translateX = 0;
		translateY = 0;
		translateZ = 0;
	}
}

void AnimatieTransformari3D::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void AnimatieTransformari3D::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void AnimatieTransformari3D::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void AnimatieTransformari3D::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void AnimatieTransformari3D::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void AnimatieTransformari3D::OnWindowResize(int width, int height)
{
}
