#include <ctime>
#include <iostream>

using namespace std;

#include <Core/Engine.h>

#include <Laboratoare/LabList.h>

int main(int argc, char **argv)
{
	srand((unsigned int)time(NULL));

	// Create a window property structure
	WindowProperties wp;
//	wp.resolution = glm::ivec2(400, 400); 
//	wp.name = std::string("Afisarea graficelor unor functii in porti diferite");
	wp.name = std::string("DesenTranslatiePatrat");

	// Init the Engine and create a new window with the defined properties
	WindowObject* window = Engine::Init(wp); 


	// Create a new 3D world and start running it
	//World *world = new AnimatieRotatiePatrat();
   // World *world = new DesenRotatiePatrat();
	//World *world = new AnimatieTranslatiePatrat();
	World *world = new DesenTranslatiePatrat();
	//World *world = new AnimatieTransformari3D();
	//World *world = new TransformareaFereastraPoartaGrafic();
	//World *world = new TransformareaFereastraPoartaPatrate();
	//World *world = new Laborator4;
	//World *world = new Laborator9;
	//World *world = new Laborator1;
	world->Init();
	world->Run();

	// Signals to the Engine to release the OpenGL context
	Engine::Exit();

	return 0;
}