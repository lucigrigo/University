 #include "AnimatieTranslatiePatrat.h"

#include <vector>
#include <iostream>

#include <Core/Engine.h>
#include "Transform2D.h"
#include "Object2D.h"

using namespace std;

AnimatieTranslatiePatrat::AnimatieTranslatiePatrat()
{
}

AnimatieTranslatiePatrat::~AnimatieTranslatiePatrat()
{
}

void AnimatieTranslatiePatrat::Init()
{

	
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	
	latura = 50;
	raza = 100;
	xc = resolution.x / 2; yc = resolution.y / 2;
	
	glm::vec3 corner = glm::vec3(0, 0, 0);
	square = Object2D::CreateSquare("square", corner, latura, glm::vec3(1, 0, 0));
	AddMeshToList(square);
	
}

void AnimatieTranslatiePatrat::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(1, 1, 1, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void AnimatieTranslatiePatrat::Update(float deltaTimeSeconds)
{
	glm::ivec2 resolution = window->GetResolution();
	xc = resolution.x / 2;
	yc = resolution.y / 2;
	
	angle += 0.5 * deltaTimeSeconds;

	modelMatrix = Transform2D::Translate(xc + raza * cos(angle) - latura / 2, yc + raza * sin(angle) - latura / 2);
	RenderMesh2D(meshes["square"], shaders["VertexColor"], modelMatrix);
}

void AnimatieTranslatiePatrat::FrameEnd()
{

}

void AnimatieTranslatiePatrat::OnInputUpdate(float deltaTime, int mods)
{
	
}

void AnimatieTranslatiePatrat::OnKeyPress(int key, int mods)
{
	// add key press event
}

void AnimatieTranslatiePatrat::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void AnimatieTranslatiePatrat::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void AnimatieTranslatiePatrat::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void AnimatieTranslatiePatrat::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void AnimatieTranslatiePatrat::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void AnimatieTranslatiePatrat::OnWindowResize(int width, int height)
{
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)width, 0, height, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	
	glm::vec3 corner = glm::vec3(0,0,0);

	square = Object2D::CreateSquare("square", corner, latura, glm::vec3(1, 0, 0));
	AddMeshToList(square);

}

