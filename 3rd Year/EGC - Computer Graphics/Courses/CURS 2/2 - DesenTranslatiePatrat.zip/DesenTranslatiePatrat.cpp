 #include "DesenTranslatiePatrat.h"

#include <vector>
#include <iostream>

#include <Core/Engine.h>
#include "Transform2D.h"
#include "Object2D.h"

using namespace std;

DesenTranslatiePatrat::DesenTranslatiePatrat()
{
}

DesenTranslatiePatrat::~DesenTranslatiePatrat()
{
}

void DesenTranslatiePatrat::Init()
{
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	
	//creaza un patrat de latura "latura", cu coltul stanga jos in originea portii de afisare (0,0)
	//centru patratului va fi in (latura/2,latura/2)

	latura = 100;
	raza = 150; //raza cercului pe care va fi translatat sau rotit patratul

	glm::vec3 corner = glm::vec3(0, 0, 0);
	square = Object2D::CreateSquare("square", corner, latura, glm::vec3(1, 0, 0));
	AddMeshToList(square);

	tx = 0; ty = 0; //vectorul de translatie curent

}

void DesenTranslatiePatrat::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(1, 1, 1, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void DesenTranslatiePatrat::Update(float deltaTimeSeconds)
{
	glm::ivec2 resolution = window->GetResolution();
	if (translate_cerc) //initial translate_cerc=0
	{
		xc = resolution.x / 2;
		yc = resolution.y / 2;

		for (int i = 0; i < nr_fig; i++)
		{
			modelMatrix = Transform2D::Translate(xc + raza * cos(0.628f*i) - latura / 2, yc + raza * sin(0.628f*i) - latura / 2);
			RenderMesh2D(square, shaders["VertexColor"], modelMatrix);

		}
	}
	else
	{
		modelMatrix = Transform2D::Translate(tx, ty);
		RenderMesh2D(square, shaders["VertexColor"], modelMatrix);
	}
}
	


void DesenTranslatiePatrat::OnKeyPress(int key, int mods)
{

	if (key == GLFW_KEY_LEFT) { tx -= 30; }
	if (key == GLFW_KEY_RIGHT) { tx += 30; }
	if (key == GLFW_KEY_DOWN) { ty -= 30; }
	if (key == GLFW_KEY_UP) { ty += 30; }
	if (key == GLFW_KEY_0) { tx += 30; ty += 30; }
	if (key == GLFW_KEY_1) { tx -= 30; ty -= 30; }

	if (key == GLFW_KEY_C){translate_cerc = 1;} // se creaza un desen prin translatia patratului pe cercul de centru (xc,yc) si raza r, de nr_fig ori
	if(key == GLFW_KEY_R) { translate_cerc = 0; } //se revine in modul de translatii la apasare taste
	if (key == GLFW_KEY_N) {
		if (nr_fig < max_fig) nr_fig++;
		else nr_fig = 0;
	}
	if (key == GLFW_KEY_D)// se creaza un desen prin translatia patratului pe cercul de centru (xc,yc) si raza r, de max_fig ori
	{nr_fig = max_fig; translate_cerc = 1;
	}

}


void DesenTranslatiePatrat::OnWindowResize(int width, int height)
{
	auto camera = GetSceneCamera();
	xc = width / 2; yc = height / 2;
	camera->SetOrthographic(0, (float)width, 0, height, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();

	xc = width / 2;
	yc = height / 2;

	glm::vec3 corner = glm::vec3(0, 0, 0);

	square = Object2D::CreateSquare("square", corner, latura, glm::vec3(1, 0, 0));
	AddMeshToList(square);

}


void DesenTranslatiePatrat::FrameEnd()
{

}

void DesenTranslatiePatrat::OnInputUpdate(float deltaTime, int mods)
{

}
void DesenTranslatiePatrat::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void DesenTranslatiePatrat::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void DesenTranslatiePatrat::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void DesenTranslatiePatrat::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void DesenTranslatiePatrat::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}