﻿#include "Laborator10.h"

#include <vector>
#include <string>
#include <iostream>

#include <Core/Engine.h>

using namespace std;

Laborator10::Laborator10()
{
}

Laborator10::~Laborator10()
{
}

void Laborator10::Init()
{
	const string textureLoc = "Source/Laboratoare/Laborator10/Textures/";

	mapType = 3;
    drawGroundPlane = false;

	// Load textures

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "earth.png").c_str(), GL_REPEAT);
		mapTextures["earth"] = texture;
	}

	{
		Texture2D* texture = new Texture2D();
		texture->Load2D((textureLoc + "tabla_sah.jpg").c_str(), GL_REPEAT);
		mapTextures["default"] = texture;
	}

	// Load meshes
	
	{
		Mesh* mesh = new Mesh("box");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("sphere1");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sphere.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("teapot");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "teapot.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	
	{ // Creaza un mesh care aproximeaza o sfera centrata in origine
	  // Se calculeaza puncte de pe sfera folosind ecuatiile parametrice ale sferei
      
	//	x = r * sin(θ)*sin(φ)          0 <= θ < 2π
	//	y = r * cos(φ)                    0 <= φ <= π
	//	z = r * cos(θ)*sin(φ)


		vector<VertexFormat> vertices;

		int columns = 50;
		int rows = 50;

		float radius = 0.5f;

		for (int i = 0; i <= columns; i++) {
			float theta = 2 * M_PI * ((float)i / columns);
			for (int j = 0; j <= rows; j++) {

				float phi = M_PI * ((float)j / rows);

				glm::vec3 pos = glm::vec3(
					radius * std::sin(theta) * std::sin(phi),//x
					radius * std::cos(phi),                  //y   
					radius * std::cos(theta) * std::sin(phi)  //z
				);

				glm::vec2 texcoord = glm::vec2(
					theta / (2 * M_PI), //u
					phi / M_PI          //v
				);

				//glm::vec3 color = glm::vec3(0, 0, 1);
				vertices.push_back(VertexFormat(pos,
					pos, //culoare
					pos,//vectorul normala este chiar pos: vectorul din originea sferei in pos 
					texcoord));
			}
		}


		vector<unsigned short> indices;

		int rows1 = rows + 1;
		int columns1 = columns + 1;

		for (int i = 1; i < columns1; i++) {
			for (int j = 1; j < rows1; j++) {
				indices.push_back((i - 1) * rows1 + j - 1);
				indices.push_back((i - 1) * rows1 + j);
				indices.push_back(i * rows1 + j - 1);

				indices.push_back((i - 1) * rows1 + j);
				indices.push_back(i * rows1 + j - 1);
				indices.push_back(i * rows1 + j);
			}
		}
	

		Mesh* mesh = new Mesh("sphere2");
		mesh->InitFromData(vertices, indices);
		meshes[mesh->GetMeshID()] = mesh;
	}

	// Create a shader program 
	{
		Shader *shader = new Shader("ShaderLab10");
		shader->AddShader("Source/Laboratoare/Laborator10/Shaders/VertexShader.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Laboratoare/Laborator10/Shaders/FragmentShader.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}
}

void Laborator10::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(1, 1, 1, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);	

	auto camera = GetSceneCamera();

	//camera->SetPerspective(60, (float) resolution.x / resolution.y, 0.01f, 100.0f);
}

void Laborator10::Update(float deltaTimeSeconds)
{
/*
	//Exemplu mipmapping
	{
		int leftMargin, backMargin;
		leftMargin = backMargin = 20;
		for (int i = -leftMargin; i <= leftMargin; i++)
			for (int j = -backMargin; j <= backMargin; j++)
			{
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i, 0, j));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(1, 0.01, 1));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab10"], modelMatrix, mapTextures["default"], 5, glm::vec3(0));
			}

	}
	
*/

	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0, -3));
		modelMatrix = glm::rotate(modelMatrix, angularStepOX, glm::vec3(1, 0, 0));
		modelMatrix = glm::rotate(modelMatrix, angularStepOY, glm::vec3(0, 1, 0));
		modelMatrix = glm::rotate(modelMatrix, angularStepOZ, glm::vec3(0, 0, 1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(2));
		//RenderSimpleMesh(meshes["sphere1"], shaders["ShaderLab10"], modelMatrix, mapTextures["earth"], mapType, glm::vec3(0));
		RenderSimpleMesh(meshes["sphere1"], shaders["ShaderLab10"], modelMatrix, mapTextures["default"], mapType, glm::vec3(0));
	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(2, 1, -2));
		modelMatrix = glm::rotate(modelMatrix, angularStepOX, glm::vec3(1, 0, 0));
		modelMatrix = glm::rotate(modelMatrix, angularStepOY, glm::vec3(0, 1, 0));
		modelMatrix = glm::rotate(modelMatrix, angularStepOZ, glm::vec3(0, 0, 1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(1.5));
	//	RenderSimpleMesh(meshes["sphere2"], shaders["ShaderLab10"], modelMatrix, mapTextures["earth"], mapType, glm::vec3(0, 0.15, 0.15));
		RenderSimpleMesh(meshes["sphere2"], shaders["ShaderLab10"], modelMatrix, mapTextures["default"], mapType, glm::vec3(0, 0.15, 0.2));
	}
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(3, -1, -3));
		modelMatrix = glm::rotate(modelMatrix, angularStepOX, glm::vec3(1, 0, 0));
		modelMatrix = glm::rotate(modelMatrix, angularStepOY, glm::vec3(0, 1, 0));
		modelMatrix = glm::rotate(modelMatrix, angularStepOZ, glm::vec3(0, 0, 1));
		RenderSimpleMesh(meshes["box"], shaders["ShaderLab10"], modelMatrix, mapTextures["default"], mapType, glm::vec3(0));
	}

	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(-3, 0, -3));
		modelMatrix = glm::rotate(modelMatrix, angularStepOX, glm::vec3(1, 0, 0));
		modelMatrix = glm::rotate(modelMatrix, angularStepOY, glm::vec3(0, 1, 0));
		modelMatrix = glm::rotate(modelMatrix, angularStepOZ, glm::vec3(0, 0, 1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(2));
		RenderSimpleMesh(meshes["teapot"], shaders["ShaderLab10"], modelMatrix, mapTextures["default"], mapType, glm::vec3(0));
	}
	
}

void Laborator10::FrameEnd()
{
	DrawCoordinatSystem();
}

void Laborator10::RenderSimpleMesh(Mesh *mesh, Shader *shader, const glm::mat4 & modelMatrix, Texture2D* texture1, int mapType, const glm::vec3 &color)
{
	if (!mesh || !shader || !shader->GetProgramID())
		return;

	// render an object using the specified shader and the specified position
	glUseProgram(shader->program);

	// Bind model matrix
	GLint loc_model_matrix = glGetUniformLocation(shader->program, "Model");
	glUniformMatrix4fv(loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	// Bind view matrix
	glm::mat4 viewMatrix = GetSceneCamera()->GetViewMatrix();
	int loc_view_matrix = glGetUniformLocation(shader->program, "View");
	glUniformMatrix4fv(loc_view_matrix, 1, GL_FALSE, glm::value_ptr(viewMatrix));

	// Bind projection matrix
	glm::mat4 projectionMatrix = GetSceneCamera()->GetProjectionMatrix();
	int loc_projection_matrix = glGetUniformLocation(shader->program, "Projection");
	glUniformMatrix4fv(loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

	glUniform1i(glGetUniformLocation(shader->program, "mapType"), mapType);
	
	int material_ke = glGetUniformLocation(shader->program, "materialKe");
	glUniform3f(material_ke, color.r, color.g, color.b);

	
	if (texture1)
	{
		glActiveTexture(GL_TEXTURE0); //activeaza unitatea de texturare

		glBindTexture(GL_TEXTURE_2D, texture1->GetTextureID());//leaga textura la unitatea de texturare
		if (!mimpap)
		{
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		}
		else
		{
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		}
	
	//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_NEAREST);//filtrare nearest din cel mai apropiat nivel
	//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);//filtrare liniara din cel mai apropiat nivel

	//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_LINEAR);
	//	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

		glUniform1i(glGetUniformLocation(shader->program, "texture_1"), 0);
	}

	// Draw the object
	glBindVertexArray(mesh->GetBuffers()->VAO);
	glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_SHORT, 0);
}

void Laborator10::OnInputUpdate(float deltaTime, int mods)
{
	float step = 2;

	if (!window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
	{
		glm::vec3 up = glm::vec3(0, 1, 0);
		glm::vec3 right = GetSceneCamera()->transform->GetLocalOXVector();
		glm::vec3 forward = GetSceneCamera()->transform->GetLocalOZVector();
		forward = glm::normalize(glm::vec3(forward.x, 0, forward.z));
	}

	if (window->KeyHold(GLFW_KEY_UP)) angularStepOX += step * deltaTime;
	if (window->KeyHold(GLFW_KEY_DOWN)) angularStepOX -= step * deltaTime;
	if (window->KeyHold(GLFW_KEY_RIGHT)) angularStepOY += step * deltaTime;
	if (window->KeyHold(GLFW_KEY_LEFT)) angularStepOY -= step * deltaTime;
	if (window->KeyHold(GLFW_KEY_PAGE_UP)) angularStepOZ += step * deltaTime;
	if (window->KeyHold(GLFW_KEY_PAGE_DOWN)) angularStepOZ -= step * deltaTime;
}



void Laborator10::OnKeyPress(int key, int mods)
{
	if (key == GLFW_KEY_1) {
		mapType = 1;
	}
	else if (key == GLFW_KEY_2) {
		mapType = 2;
	}
	else if (key == GLFW_KEY_3) {
		mapType = 3;
	}

	else if (key == GLFW_KEY_SPACE) {
		angularStepOX = 0;
		angularStepOY = 0;
		angularStepOZ = 0;

	}
	else if (key == GLFW_KEY_Z) {
		mimpap = !mimpap;
	}
	
}

void Laborator10::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Laborator10::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void Laborator10::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void Laborator10::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Laborator10::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Laborator10::OnWindowResize(int width, int height)
{
}
