﻿#include "C9_Ceata.h"

#include <vector>
#include <string>
#include <iostream>

#include <Core/Engine.h>

using namespace std;

C9_Ceata::C9_Ceata()
{
}

C9_Ceata::~C9_Ceata()
{
}

void C9_Ceata::Init()
{
	drawGroundPlane = false;  //fara desenare grid - SimpleScene.h modificat

	{
		Mesh* mesh = new Mesh("box");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("sphere");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sphere.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("plane");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "plane50.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	// Create a shader program for drawing using a lighting model
	{
		Shader *shader = new Shader("ShaderLight");
		shader->AddShader("Source/Laboratoare/C9_Ceata/Shaders/VertexShader.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Laboratoare/C9_Ceata/Shaders/FragmentShader.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}

	//Light & material properties
	{
		lightPosition = glm::vec3(1.8f, 5.5f, 0.0f);
		lightDirection = glm::vec3(0, -1, 0);
		materialShininess = 30;
		materialKd = 0.5;
		materialKs = 0.5;
	}

	// Set camera to a new position
	{
		useCamera(glm::vec3(0.5f, 0.5f, 5), glm::vec3(0.0, 0.0, -1.0), 0.01f, 10.0f);
	}

	// Set animation values
	// - rotationAngle: both cubes will spin
	// - translationObj: only the bottom cube will move in the scene
	// - translationDir: direction of the translation
	rotationAngle = 0.0f;
	translationObj = 0.0f;
	translationDir = 1.0f;

	showCamerasPositionsArrows = false;
	displayIn4Views = false;
	showVisualVolumeFrontCamera = false;
	showHud = true;

	fogOn = 0;
	fogSelector = FOG_LINEAR;

	// Text renderer
	glm::ivec2 resolution = window->GetResolution();
	Text = new TextRenderer(resolution.x, resolution.y);
	
	Text->Load("Source/Laboratoare/C9_Ceata/TextRenderer/Fonts/Arial.ttf", 18);

}

void C9_Ceata::drawHud()
{
	if (!showHud)
		return;

	Text->RenderText("Utilizare taste", 5.0f, 5.0f, 1.0f, glm::vec3(0.0, 1.0, 0.0));
	Text->RenderText("'space'  : Toggle Solid/Wireframe/Points", 5.0f, 25.0f, 1.0f, glm::vec3(0.0, 1.0, 0.0));
	
	std::string fogOnText = +fogOn ? "ON" : "OFF";
	Text->RenderText("'f'  : Activare/Dezactivare ceata (current status "+ fogOnText +")", 5.0f, 50.0f, 1.0f, glm::vec3(0.0, 1.0, 0.0));
	
	std::string fogType = "";
	if(fogSelector == FOG_LINEAR)
		fogType = "FOG LINEAR";
	if (fogSelector == FOG_EXP)
		fogType = "FOG EXP";
	if (fogSelector == FOG_EXP2)
		fogType = "FOG EXP2";

	Text->RenderText("'g'  : Activare LINEAR fog (ceata curenta " + fogType + ")", 5.0f, 75.0f, 1.0f, glm::vec3(0.0, 1.0, 0.0));
	Text->RenderText("'h'  : Activare EXP fog (ceata curenta " + fogType + ")", 5.0f, 100.0f, 1.0f, glm::vec3(0.0, 1.0, 0.0));
	Text->RenderText("'j'  : Activare EXP2 fog (ceata curenta " + fogType + ")", 5.0f, 125.0f, 1.0f, glm::vec3(0.0, 1.0, 0.0));
}

void C9_Ceata::FrameStart()
{
	// clears the color buffer and depth buffer
	glClearColor(0.5, 0.5, 0.5, 0); // culoarea cetii
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);	

}

void C9_Ceata::AnimateObjectsParameters(glm::vec3 translate, glm::vec3 rotate, glm::vec3 scale, float deltaTimeSeconds)
{
	translationObj += (translate.x * translationDir) * deltaTimeSeconds;
	rotationAngle += RADIANS((rotate.y * deltaTimeSeconds));

	if (translationObj >= 4 || translationObj <= -4)
	{
		translationDir *= -1;
		if (translationObj >= 4)
			translationObj = 4;
		if (translationObj <= -4)
			translationObj = -4;
	}
}

void C9_Ceata::RenderScene(float deltaTimeSeconds)
{
	// Render ground
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(0, -0.01f, 0));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.5f));
		
		RenderSimpleMesh(meshes["plane"], shaders["ShaderLight"], modelMatrix, glm::vec3(0.0, 0.5, 0));
	}
		
	// Cub galben
	{
		glm::mat4 modelMatrix = glm::mat4(1);

		glm::vec3 translation = glm::vec3(translationObj, 1.0, 0);
		
		modelMatrix = glm::translate(modelMatrix, translation);
		modelMatrix = glm::rotate(modelMatrix, rotationAngle, glm::vec3(0, 1, 0));

		RenderSimpleMesh(meshes["box"], shaders["ShaderLight"], modelMatrix, glm::vec3(1, 1, 0));
	}

	// Cub rosu
	{
		glm::mat4 modelMatrix = glm::mat4(1);

		//glm::vec3 translation = glm::vec3(1.0, 3.5, 0);

		modelMatrix = glm::translate(modelMatrix, glm::vec3(3.0, 2.5, -1));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.6, 0.6, 0.6));
		modelMatrix = glm::rotate(modelMatrix, rotationAngle, glm::vec3(0, 1, 0));

		RenderSimpleMesh(meshes["box"], shaders["ShaderLight"], modelMatrix, glm::vec3(1.0, 0.0, 0));
	}

	//Sfera
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(1,1.5,-2));
	    modelMatrix = glm::scale(modelMatrix, glm::vec3(2.5f));
		// Render the sphere only if we are not building the shadow map depth buffer
		RenderMesh(meshes["sphere"], shaders["ShaderLight"], modelMatrix);
	}
	

	// Sfera in pozitia sursei de lumina
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, lightPosition);
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.2f));
		// Render the sphere only if we are not building the shadow map depth buffer
		RenderMesh(meshes["sphere"], shaders["Simple"], modelMatrix);
	}

	drawHud();

}

void C9_Ceata::Update(float deltaTimeSeconds)
{

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);

	RenderScene(deltaTimeSeconds);

	// Translate and rotate cubes in the scene
	AnimateObjectsParameters(glm::vec3(2.5f, 0.0f, 0.0f), glm::vec3(0.0f, 30.0f, 0.0f), glm::vec3(1.0f), deltaTimeSeconds);
}

void C9_Ceata::FrameEnd()
{
	DrawCoordinatSystem();
}

void C9_Ceata::RenderSimpleMesh(Mesh *mesh, Shader *shader, const glm::mat4 & modelMatrix, const glm::vec3 &color, const float obj_alpha)
{
	if (!mesh || !shader || !shader->GetProgramID())
		return;

	// render an object using the specified shader and the specified position
	glUseProgram(shader->program);

	// Set shader uniforms for light & material properties
	// Set light position uniform
	int light_position = glGetUniformLocation(shader->program, "light_position");
	glUniform3f(light_position, lightPosition.x, lightPosition.y, lightPosition.z);

	int light_direction = glGetUniformLocation(shader->program, "light_direction");
	glUniform3f(light_direction, lightDirection.x, lightDirection.y, lightDirection.z);

	// Set eye position (camera position) uniform
	glm::vec3 eyePosition = GetSceneCamera()->transform->GetWorldPosition();
	int eye_position = glGetUniformLocation(shader->program, "eye_position");
	glUniform3f(eye_position, eyePosition.x, eyePosition.y, eyePosition.z);

	// Set material property uniforms (shininess, kd, ks, object color) 
	int material_shininess = glGetUniformLocation(shader->program, "material_shininess");
	glUniform1i(material_shininess, materialShininess);

	int material_kd = glGetUniformLocation(shader->program, "material_kd");
	glUniform1f(material_kd, materialKd);

	int material_ks = glGetUniformLocation(shader->program, "material_ks");
	glUniform1f(material_ks, materialKs);

	int object_color = glGetUniformLocation(shader->program, "object_color");
	glUniform3f(object_color, color.r, color.g, color.b);

	int object_alpha = glGetUniformLocation(shader->program, "object_alpha");
	glUniform1f(object_alpha, obj_alpha);

	int fog_on = glGetUniformLocation(shader->program, "fogOn");
	glUniform1i(fog_on, fogOn);

	int fog_selector = glGetUniformLocation(shader->program, "fogSelector");
	glUniform1i(fog_selector, fogSelector);

	// Bind model matrix
	GLint loc_model_matrix = glGetUniformLocation(shader->program, "Model");
	glUniformMatrix4fv(loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	// Bind view matrix
	glm::mat4 viewMatrix = GetSceneCamera()->GetViewMatrix();
	int loc_view_matrix = glGetUniformLocation(shader->program, "View");
	glUniformMatrix4fv(loc_view_matrix, 1, GL_FALSE, glm::value_ptr(viewMatrix));

	// Bind projection matrix
	glm::mat4 projectionMatrix = GetSceneCamera()->GetProjectionMatrix();
	int loc_projection_matrix = glGetUniformLocation(shader->program, "Projection");
	glUniformMatrix4fv(loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

	// Draw the object
	glBindVertexArray(mesh->GetBuffers()->VAO);
	glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_SHORT, 0);
}

// Documentation for the input functions can be found in: "/Source/Core/Window/InputController.h" or
// https://github.com/UPB-Graphics/Framework-EGC/blob/master/Source/Core/Window/InputController.h

void C9_Ceata::OnInputUpdate(float deltaTime, int mods)
{
	float speed = 2;

	if (!window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
	{
		glm::vec3 up = glm::vec3(0, 1, 0);
		glm::vec3 right = GetSceneCamera()->transform->GetLocalOXVector();
		glm::vec3 forward = GetSceneCamera()->transform->GetLocalOZVector();
		forward = glm::normalize(glm::vec3(forward.x, 0, forward.z));

		// Control light position using on W, A, S, D, E, Q
		if (window->KeyHold(GLFW_KEY_W)) lightPosition -= forward * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_A)) lightPosition -= right * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_S)) lightPosition += forward * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_D)) lightPosition += right * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_E)) lightPosition += up * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_Q)) lightPosition -= up * deltaTime * speed;
	}
}

void C9_Ceata::setCameraViewMatrix(glm::vec3 cameraPosition, glm::vec3 lookAtDirection)
{
	GetSceneCamera()->transform->SetWorldPosition(cameraPosition);
	glm::vec3 worldRotation = glm::vec3(0.0f, 0.0f, 0.0f);
	// Back camera
	if (lookAtDirection.z == 1.0f)
		worldRotation.y = -180.0f;
	// Top camera
	if (lookAtDirection.y == -1.0f)
		worldRotation.x = -90.0f;
	// Left camera
	if (lookAtDirection.x == 1.0f)
		worldRotation.y = -90.0f;
	// Right camera
	if (lookAtDirection.x == -1.0f)
		worldRotation.y = 90.0f;

	GetSceneCamera()->transform->SetWorldRotation(worldRotation);

	GetSceneCamera()->Update();
}

void C9_Ceata::useCamera(glm::vec3 cameraPosition, glm::vec3 lookAtDirection, float zNear, float zFar)
{
	glm::ivec2 resolution = window->GetResolution();
			
	//glm::mat4 cameraProjection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.01f, 40.0f);
	glm::mat4 cameraProjection = glm::perspective(RADIANS(90), (float)resolution.x / (float)resolution.y, zNear, zFar);
		
	GetSceneCamera()->Projection = cameraProjection;
	setCameraViewMatrix(cameraPosition, lookAtDirection);
	GetSceneCamera()->Update();
}

void C9_Ceata::OnKeyPress(int key, int mods)
{
		
	if (key == GLFW_KEY_M)
	{
		showHud = !showHud;
	}
	if (key == GLFW_KEY_F)
	{
		fogOn = !fogOn;
	}
	if (key == GLFW_KEY_G)
	{
		fogSelector = FOG_LINEAR;
	}
	if (key == GLFW_KEY_H)
	{
		fogSelector = FOG_EXP;
	}
	if (key == GLFW_KEY_J)
	{
		fogSelector = FOG_EXP2;
	}
}

void C9_Ceata::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void C9_Ceata::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void C9_Ceata::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void C9_Ceata::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void C9_Ceata::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void C9_Ceata::OnWindowResize(int width, int height)
{
}
