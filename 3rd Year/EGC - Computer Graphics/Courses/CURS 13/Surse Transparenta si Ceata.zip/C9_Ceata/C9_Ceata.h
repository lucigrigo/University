#pragma once
#include <Component/SimpleScene.h>
#include <Component/Transform/Transform.h>
#include <Core/GPU/Mesh.h>
#include "TextRenderer/TextRenderer.h"

class C9_Ceata : public SimpleScene
{
	public:
		C9_Ceata();
		~C9_Ceata();

		void Init() override;

	private:
		void FrameStart() override;
		void Update(float deltaTimeSeconds) override;
		void FrameEnd() override;

		void AnimateObjectsParameters(glm::vec3 translate, glm::vec3 rotate, glm::vec3 scale, float deltaTimeSeconds);

		void RenderSimpleMesh(Mesh *mesh, Shader *shader, const glm::mat4 &modelMatrix, const glm::vec3 &color = glm::vec3(1), const float obj_alpha = 1.0f);
		void RenderScene(float deltaTimeSeconds);
		
		void extrude(glm::vec3 &n, glm::vec3 light, glm::vec3 vertex, float t);
		bool faceIsVisibleFromLight(glm::vec3 v1, glm::vec3 v2, glm::vec3 v3, glm::vec3 lightPosition);
		
		void drawHud();

		void useCamera(glm::vec3 cameraPosition, glm::vec3 lookAtDirection, float zNear, float zFar);
		void setCameraViewMatrix(glm::vec3 cameraPosition, glm::vec3 lookAtDirection);

		void OnInputUpdate(float deltaTime, int mods) override;
		void OnKeyPress(int key, int mods) override;
		void OnKeyRelease(int key, int mods) override;
		void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
		void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
		void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
		void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
		void OnWindowResize(int width, int height) override;

		void DrawCameraPositionsArrows(const glm::mat4 & viewMatrix, const glm::mat4 & projectionMatrix);
		void DrawCameraPositionsPoints(glm::vec3 cameraPosition);

		void renderVisualVolumeFace(std::vector<VertexFormat> vertices, std::vector<unsigned short> indices);
		void makeCameraVisualVolume(glm::vec3 cameraPosition, glm::vec3 lookAtDirection, float fov, float aspect, float zNear, float zFar);
		
		glm::vec3 lightPosition;
		glm::vec3 lightDirection;
		unsigned int materialShininess;
		float materialKd;
		float materialKs;

		// The text renderer
		TextRenderer  *Text;

		// Draw primitives mode
		GLenum polygonMode;

		// Animation parameters
		float rotationAngle, translationObj;
		float translationDir;
		bool showCamerasPositionsArrows;
		bool showVisualVolumeFrontCamera;
		bool displayIn4Views;
		bool showHud;

		// Cameras positions
		glm::vec3 cameraFrontPosition;
		glm::vec3 cameraBackPosition;
		glm::vec3 cameraTopPosition;
		glm::vec3 cameraLeftPosition;
		glm::vec3 cameraRightPosition;

		EngineComponents::Transform *objectModel;
		Mesh *simpleLine;
		Mesh *arrow;

		// Fog
		int fogOn;
		int fogSelector;
		const int FOG_LINEAR = 1;
		const int FOG_EXP = 2;
		const int FOG_EXP2 = 3;
};
