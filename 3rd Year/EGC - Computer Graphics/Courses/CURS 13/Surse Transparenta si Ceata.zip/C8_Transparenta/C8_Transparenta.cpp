#include "C8_Transparenta.h"

#include <vector>
#include <string>
#include <iostream>

#include <Core/Engine.h>

using namespace std;

C8_Transparenta::C8_Transparenta()
{
}

C8_Transparenta::~C8_Transparenta()
{
}

void C8_Transparenta::Init()
{
	drawGroundPlane = false; //fara desenare grid - SimpleScene.h modificat
	polygonMode = GL_FILL;
	{

		Mesh* mesh = new Mesh("box");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("plane");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "plane50.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	// Create a shader program for drawing using a lighting model
	{
		Shader *shader = new Shader("ShaderLight");
		shader->AddShader("Source/Laboratoare/C8_Transparenta/Shaders/VertexShader.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Laboratoare/C8_Transparenta/Shaders/FragmentShader.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}

	//Light & material properties
	{
		lightPosition = glm::vec3(1.8f, 5.5f, 0.0f);
		materialShininess = 30;
		materialKd = 0.5;
		materialKs = 0.5;
	}

	// Set camera to a new position
	{
		GetSceneCamera()->transform->SetWorldPosition(glm::vec3(0.0f, 2.5f, 8.0f));
		GetSceneCamera()->SetPerspective(60, window->props.aspectRatio, 0.01f, 200.0f);
		GetSceneCamera()->Update();
	}

	// Set animation values
	// - rotationAngle: both cubes will spin
	// - translationObj: only the bottom cube will move in the scene
	// - translationDir: direction of the translation
	rotationAngle = 0.0f;
	translationObj = 0.0f;
	translationDir = 1.0f;
	
}

void C8_Transparenta::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
	// Alfa blending
	

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);	
	DrawCoordinatSystem();

}

void C8_Transparenta::AnimateObjectsParameters(glm::vec3 translate, glm::vec3 rotate, glm::vec3 scale, float deltaTimeSeconds)
{
	translationObj += (translate.x * translationDir) * deltaTimeSeconds;
	rotationAngle += RADIANS((rotate.y * deltaTimeSeconds));

	if (translationObj >= 3 || translationObj <= -3)
	{
		translationDir *= -1;
		if (translationObj >= 3)
			translationObj = 3;
		if (translationObj <= -3)
			translationObj = -3;
	}
}

void C8_Transparenta::RenderScene(float deltaTimeSeconds)
{
	// Render ground
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(0, -0.01f, 0));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.5f));
		
		RenderSimpleMesh(meshes["plane"], shaders["ShaderLight"], modelMatrix, glm::vec3(0.0, 0.5, 0));
	}

	// Cub albastru rasterizat inaintea cubului rosu
	{
		glm::mat4 modelMatrix = glm::mat4(1);

		glm::vec3 translation = glm::vec3(translationObj, 1.0, 0);
		
		modelMatrix = glm::translate(modelMatrix, translation);
		modelMatrix = glm::rotate(modelMatrix, rotationAngle, glm::vec3(0, 1, 0));

		RenderSimpleMesh(meshes["box"], shaders["ShaderLight"], modelMatrix, glm::vec3(0, 0, 1));
	}
	
	// Cub rosu
	{
		glm::mat4 modelMatrix = glm::mat4(1);

		glm::vec3 translation = glm::vec3(translationObj, 1.5, 3);

		modelMatrix = glm::translate(modelMatrix, translation);
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.6, 0.6, 0.6));
		modelMatrix = glm::rotate(modelMatrix, rotationAngle, glm::vec3(0, 1, 0));

		// Red cube is transparent - alpha is 0.3
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		RenderSimpleMesh(meshes["box"], shaders["ShaderLight"], modelMatrix, glm::vec3(1.0, 0.0, 0.0), 0.3f);

		glDisable(GL_BLEND);
		glDisable(GL_CULL_FACE);

	/*
		// Cub albastru rasterizat dupa cubul rosu
		{
			glm::mat4 modelMatrix = glm::mat4(1);

			glm::vec3 translation = glm::vec3(translationObj, 1.0, 0);

			modelMatrix = glm::translate(modelMatrix, translation);
			modelMatrix = glm::rotate(modelMatrix, rotationAngle, glm::vec3(0, 1, 0));

			RenderSimpleMesh(meshes["box"], shaders["ShaderLight"], modelMatrix, glm::vec3(0, 0, 1));
		}

	*/
		
	}

	// Render a sphere in the scene at the point light position
	{
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, lightPosition);
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.2f));
		// Render the sphere only if we are not building the shadow map depth buffer
		RenderMesh(meshes["sphere"], shaders["Simple"], modelMatrix);
	}

}

void C8_Transparenta::Update(float deltaTimeSeconds)
{
	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);

	RenderScene(deltaTimeSeconds);

	// Translate and rotate cubes in the scene
	AnimateObjectsParameters(glm::vec3(2.5f, 0.0f, 0.0f), glm::vec3(0.0f, 30.0f, 0.0f), glm::vec3(1.0f), deltaTimeSeconds);

}

void C8_Transparenta::FrameEnd()
{
	//DrawCoordinatSystem();
}

// 2 additional param
void C8_Transparenta::RenderSimpleMesh(Mesh *mesh, Shader *shader, const glm::mat4 & modelMatrix, const glm::vec3 &color, const float obj_alpha)
{
	if (!mesh || !shader || !shader->GetProgramID())
		return;

	// render an object using the specified shader and the specified position
	glUseProgram(shader->program);

	// Set shader uniforms for light & material properties
	// Set light position uniform
	int light_position = glGetUniformLocation(shader->program, "light_position");
	glUniform3f(light_position, lightPosition.x, lightPosition.y, lightPosition.z);

	// Set eye position (camera position) uniform
	glm::vec3 eyePosition = GetSceneCamera()->transform->GetWorldPosition();
	int eye_position = glGetUniformLocation(shader->program, "eye_position");
	glUniform3f(eye_position, eyePosition.x, eyePosition.y, eyePosition.z);

	// Set material property uniforms (shininess, kd, ks, object color) 
	int material_shininess = glGetUniformLocation(shader->program, "material_shininess");
	glUniform1i(material_shininess, materialShininess);

	int material_kd = glGetUniformLocation(shader->program, "material_kd");
	glUniform1f(material_kd, materialKd);

	int material_ks = glGetUniformLocation(shader->program, "material_ks");
	glUniform1f(material_ks, materialKs);

	int object_color = glGetUniformLocation(shader->program, "object_color");
	glUniform3f(object_color, color.r, color.g, color.b);

	int object_alpha = glGetUniformLocation(shader->program, "object_alpha");
	glUniform1f(object_alpha, obj_alpha);

	// Bind model matrix
	GLint loc_model_matrix = glGetUniformLocation(shader->program, "Model");
	glUniformMatrix4fv(loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	// Bind view matrix
	glm::mat4 viewMatrix = GetSceneCamera()->GetViewMatrix();
	int loc_view_matrix = glGetUniformLocation(shader->program, "View");
	glUniformMatrix4fv(loc_view_matrix, 1, GL_FALSE, glm::value_ptr(viewMatrix));

	// Bind projection matrix
	glm::mat4 projectionMatrix = GetSceneCamera()->GetProjectionMatrix();
	int loc_projection_matrix = glGetUniformLocation(shader->program, "Projection");
	glUniformMatrix4fv(loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

	// Draw the object
	glBindVertexArray(mesh->GetBuffers()->VAO);
	glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_SHORT, 0);
}

// Documentation for the input functions can be found in: "/Source/Core/Window/InputController.h" or
// https://github.com/UPB-Graphics/Framework-EGC/blob/master/Source/Core/Window/InputController.h

void C8_Transparenta::OnInputUpdate(float deltaTime, int mods)
{
	float speed = 1;

	if (!window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
	{
		glm::vec3 up = glm::vec3(0, 1, 0);
		glm::vec3 right = GetSceneCamera()->transform->GetLocalOXVector();//??
		glm::vec3 forward = GetSceneCamera()->transform->GetLocalOZVector();
		forward = glm::normalize(glm::vec3(forward.x, 0, forward.z));

		// Control light position using on W, A, S, D, E, Q
		if (window->KeyHold(GLFW_KEY_W)) lightPosition -= forward * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_A)) lightPosition -= right * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_S)) lightPosition += forward * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_D)) lightPosition += right * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_E)) lightPosition += up * deltaTime * speed;
		if (window->KeyHold(GLFW_KEY_Q)) lightPosition -= up * deltaTime * speed;
	}
}

void C8_Transparenta::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void C8_Transparenta::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void C8_Transparenta::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void C8_Transparenta::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void C8_Transparenta::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void C8_Transparenta::OnWindowResize(int width, int height)
{
}
