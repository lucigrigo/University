#include "Object2DGrafic.h"

#include <Core/Engine.h>
#include <iostream>

Mesh* Object2DGrafic::CreateFunctionPlot(std::string name, float &x1, float &x2, float &y1, float &y2, float pas, float(*f)(double f))
{

	// traseaza graficul functiei matematice y = f(x), in intervalul xmin- xmax  
	float x, y, xmin=x1, xmax=x2;

	// calculeaza incadrarea graficului pe axa OY( [y1-y2]) in intervalul xmin - xmax
	y1 = y2 = f(xmin);
	for (x = xmin + pas; x<xmax; x += pas)
	{
		if ((y = f(x))<y1) y1 = y;
		if (y>y2)y2 = y;
	}

	if ((y = f(xmax))<y1) y1 = y;
	if (y>y2)y2 = y;

	// Include axele in fereastra
	if (0<xmin)x1 = 0; else x1 = xmin;
	if (0<y1)y1 = 0;
	if (0>xmax)x2 = 0; else x2 = xmax;
	if (0>y2)y2 = 0;
	//ymin = y1;
//	ymax = y2;

	Mesh* plot = new Mesh(name);
	plot->SetDrawMode(GL_LINES);

	std::vector<VertexFormat> vertices;
	vertices.push_back(VertexFormat(glm::vec3(x1, 0, 0), glm::vec3(0, 0, 1)));
	vertices.push_back(VertexFormat(glm::vec3(x2, 0, 0), glm::vec3(0, 0, 1)));
	vertices.push_back(VertexFormat(glm::vec3(0, y1, 0), glm::vec3(0, 0, 1)));
	vertices.push_back(VertexFormat(glm::vec3(0, y2, 0), glm::vec3(0, 0, 1)));
	
	std::vector<unsigned short> indices;
	indices.push_back(0);
	indices.push_back(1);
	indices.push_back(2);
	indices.push_back(3);
	int contor = 4;
	
	for (x = xmin; x<xmax - pas; x += pas)
	{
		vertices.push_back(VertexFormat(glm::vec3(x, f(x), 0), glm::vec3(1, 0, 0)));
		indices.push_back(contor);
		indices.push_back(contor+1);
		contor++;
	}
	vertices.push_back(VertexFormat(glm::vec3(xmax, f(xmax), 0), glm::vec3(1, 0, 0)));
		

	plot->InitFromData(vertices, indices);
	return plot;
	
}
