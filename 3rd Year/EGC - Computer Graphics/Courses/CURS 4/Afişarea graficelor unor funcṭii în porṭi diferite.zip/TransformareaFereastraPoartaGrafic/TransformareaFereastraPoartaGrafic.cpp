#include "TransformareaFereastraPoartaGrafic.h"

#include <vector>
#include <iostream>

#include <Core/Engine.h>
#include "Transform2D.h"
#include "Object2DGrafic.h"

using namespace std;

TransformareaFereastraPoartaGrafic::TransformareaFereastraPoartaGrafic()
{
}

TransformareaFereastraPoartaGrafic::~TransformareaFereastraPoartaGrafic()
{
}

float f1(double x)
{
	return (float)(sin(10 * x)*x);
}

float f2(double x)
{
	return (float)(tan(x));
}

float f3(double x)
{
	return (float)(sin(10 * x));
}

float f4(double x)
{
	return (float)((x * x - 2) * (x + 3));
}



void TransformareaFereastraPoartaGrafic::Init()
{
	auto camera = GetSceneCamera();
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	
    float y1, y2, x1=-5.0f, x2 = 5.0f;
//	float y1, y2, x1 = -5.0f, x2 = 0.0f;
//	float y1, y2, x1 = 0.0f, x2 = 5.0f;
	Mesh* mesh_f1 = Object2DGrafic::CreateFunctionPlot("mesh_f1", x1, x2, y1, y2, 0.01f, f1);
	AddMeshToList(mesh_f1);
	logicSpace1.x = x1;
	logicSpace1.width = x2 - x1;
	logicSpace1.y = y1;
	logicSpace1.height = y2 - y1;

	Mesh* mesh_f2 = Object2DGrafic::CreateFunctionPlot("mesh_f2", x1, x2, y1, y2, 0.1f, f2);
	AddMeshToList(mesh_f2);
	logicSpace2.x = x1;
	logicSpace2.width = x2 - x1;
	logicSpace2.y = y1;
	logicSpace2.height = y2 - y1;

	Mesh* mesh_f3 = Object2DGrafic::CreateFunctionPlot("mesh_f3", x1, x2, y1, y2, 0.01f, f3);
	AddMeshToList(mesh_f3);
	logicSpace3.x = x1;
	logicSpace3.width = x2 - x1;
	logicSpace3.y = y1;
	logicSpace3.height = y2 - y1;

	Mesh* mesh_f4 = Object2DGrafic::CreateFunctionPlot("mesh_f4", x1, x2, y1, y2, 0.01f, f4);
	AddMeshToList(mesh_f4);
	logicSpace4.x = x1;
	logicSpace4.width = x2 - x1;
	logicSpace4.y = y1;
	logicSpace4.height = y2 - y1;


	// Create shader programs
	{
		Shader *shader = new Shader("ShaderGrafic");
		shader->AddShader("Source/Laboratoare/TransformareaFereastraPoartaGrafic/Shaders/VertexShader.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Laboratoare/TransformareaFereastraPoartaGrafic/Shaders/FragmentShader.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}

}

// 2D visualization matrix
glm::mat3 TransformareaFereastraPoartaGrafic::VisualizationTransf2D(const LogicSpace & logicSpace, const ViewportSpace & viewSpace)
{
	float sx, sy, tx, ty;
	sx = viewSpace.width / logicSpace.width;
	sy = viewSpace.height / logicSpace.height;
	tx = viewSpace.x - sx * logicSpace.x;
	ty = viewSpace.y - sy * logicSpace.y;

	return glm::transpose(glm::mat3(
		sx, 0.0f, tx,
		0.0f, sy, ty,
		0.0f, 0.0f, 1.0f));
}

// uniform 2D visualization matrix (same scale factor on x and y axes)
glm::mat3 TransformareaFereastraPoartaGrafic::VisualizationTransf2DUnif(const LogicSpace & logicSpace, const ViewportSpace & viewSpace)
{
	float sx, sy, tx, ty, smin;
	sx = viewSpace.width / logicSpace.width;
	sy = viewSpace.height / logicSpace.height;
	if (sx < sy)
		smin = sx;
	else
		smin = sy;
	tx = viewSpace.x - smin * logicSpace.x + (viewSpace.width - smin * logicSpace.width) / 2;
	ty = viewSpace.y - smin * logicSpace.y + (viewSpace.height - smin * logicSpace.height) / 2;

	return glm::transpose(glm::mat3(
		smin, 0.0f, tx,
		0.0f, smin, ty,
		0.0f, 0.0f, 1.0f));
}

void TransformareaFereastraPoartaGrafic::SetViewportArea(const ViewportSpace & viewSpace, glm::vec3 colorColor, bool clear)
{
//	int delta = 0;
	int delta = 2;
	glViewport(viewSpace.x + delta, viewSpace.y + delta, viewSpace.width - delta * 2, viewSpace.height - delta * 2);

	glEnable(GL_SCISSOR_TEST);
	glScissor(viewSpace.x+delta, viewSpace.y+delta, viewSpace.width-delta * 2, viewSpace.height- delta * 2);

	// Clears the color buffer and depth buffer
	glClearColor(colorColor.r, colorColor.g, colorColor.b, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glDisable(GL_SCISSOR_TEST);

	GetSceneCamera()->SetOrthographic((float)viewSpace.x, (float)(viewSpace.x + viewSpace.width), (float)viewSpace.y, (float)(viewSpace.y + viewSpace.height), 0.1f, 400);
	GetSceneCamera()->Update();
}

void TransformareaFereastraPoartaGrafic::FrameStart()
{
	// Clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0.5, 0.5, 0.5, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

}

void TransformareaFereastraPoartaGrafic::Update(float deltaTimeSeconds)
{

	glm::ivec2 resolution = window->GetResolution();

	//Sets the screen area where to draw - upper right part
	viewSpace = ViewportSpace(resolution.x / 2, resolution.y / 2, resolution.x / 2, resolution.y / 2);
    SetViewportArea(viewSpace, glm::vec3(1,1,1), true);
	visMatrix = VisualizationTransf2D(logicSpace1, viewSpace);
	DrawFunctionPlot(visMatrix, 1);

	//upper left part
	viewSpace = ViewportSpace(0, resolution.y / 2, resolution.x / 2, resolution.y / 2);
	SetViewportArea(viewSpace, glm::vec3(1, 0.98, 0.95), true);
	visMatrix = VisualizationTransf2D(logicSpace2, viewSpace);
	DrawFunctionPlot(visMatrix, 2);
	
   // the lower left part of the window
	viewSpace = ViewportSpace(0, 0, resolution.x / 2, resolution.y / 2);
    SetViewportArea(viewSpace, glm::vec3(1, 0.98, 0.95), true);
	visMatrix = VisualizationTransf2D(logicSpace3, viewSpace);
	DrawFunctionPlot(visMatrix, 3);


	//lower right part of the window
	viewSpace = ViewportSpace(resolution.x / 2, 0, resolution.x / 2, resolution.y / 2);
    SetViewportArea(viewSpace, glm::vec3(1, 0.98, 0.95), true);
	visMatrix = VisualizationTransf2D(logicSpace4, viewSpace);
	DrawFunctionPlot(visMatrix, 4);


}

void TransformareaFereastraPoartaGrafic::FrameEnd()
{

}


void TransformareaFereastraPoartaGrafic::DrawFunctionPlot(glm::mat3 visMatrix, int nr_functie)
{
	modelMatrix = visMatrix;
	switch (nr_functie)
	{
	case 1:
		RenderMesh2D(meshes["mesh_f1"],shaders["ShaderGrafic"],modelMatrix);
		break;
	case 2:
		RenderMesh2D(meshes["mesh_f2"], shaders["ShaderGrafic"], modelMatrix);
		break;
	case 3:
		RenderMesh2D(meshes["mesh_f3"], shaders["ShaderGrafic"], modelMatrix);
		break;
	case 4:
		RenderMesh2D(meshes["mesh_f4"], shaders["ShaderGrafic"], modelMatrix);
		break;
	default:
		break;
	}
	
	   
}


void TransformareaFereastraPoartaGrafic::OnInputUpdate(float deltaTime, int mods)
{
	//TODO move the logic window with W, A, S, D (up, left, down, right)
	//TODO zoom in and zoom out logic window with Z and X
}

void TransformareaFereastraPoartaGrafic::OnKeyPress(int key, int mods)
{

}

void TransformareaFereastraPoartaGrafic::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void TransformareaFereastraPoartaGrafic::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void TransformareaFereastraPoartaGrafic::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void TransformareaFereastraPoartaGrafic::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void TransformareaFereastraPoartaGrafic::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}