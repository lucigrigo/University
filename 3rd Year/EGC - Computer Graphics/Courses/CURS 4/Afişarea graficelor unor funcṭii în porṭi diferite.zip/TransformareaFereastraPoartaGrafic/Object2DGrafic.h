#pragma once

#include <string>

#include <include/glm.h>
#include <Core/GPU/Mesh.h>

namespace Object2DGrafic
{

	Mesh* CreateFunctionPlot(std::string name, float &xmin, float &xmax, float &ymin, float &ymax, float pas, float(*f)(double f));
}

