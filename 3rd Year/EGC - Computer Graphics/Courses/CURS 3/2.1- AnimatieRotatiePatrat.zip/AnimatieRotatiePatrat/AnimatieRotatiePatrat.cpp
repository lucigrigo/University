 #include "AnimatieRotatiePatrat.h"

#include <vector>
#include <iostream>

#include <Core/Engine.h>
#include "Transform2D.h"
#include "Object2D.h"



using namespace std;

AnimatieRotatiePatrat::AnimatieRotatiePatrat()
{
}

AnimatieRotatiePatrat::~AnimatieRotatiePatrat()
{
}

void AnimatieRotatiePatrat::Init()
{

	
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	
	latura = 100;
	raza = 200;
	xc = resolution.x / 2; yc = resolution.y / 2;

	
	glm::vec3 corner = glm::vec3(0, 0, 0);
	
	square = Object2D::CreateSquare("square", corner, latura, glm::vec3(1, 0, 0));
	AddMeshToList(square);

	
}

void AnimatieRotatiePatrat::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(1, 1, 1, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void AnimatieRotatiePatrat::Update(float deltaTimeSeconds)
{
	glm::ivec2 resolution = window->GetResolution();
	xc = resolution.x / 2;
	yc = resolution.y / 2;

	angle += 0.5 * deltaTimeSeconds;
		
	modelMatrix = Transform2D::Translate(xc,yc) *
	Transform2D::Rotate(angle) *
	Transform2D::Translate(raza -latura/2, -latura / 2);
	RenderMesh2D(meshes["square"], shaders["VertexColor"], modelMatrix);

}

void AnimatieRotatiePatrat::FrameEnd()
{

}

void AnimatieRotatiePatrat::OnInputUpdate(float deltaTime, int mods)
{
	
}

void AnimatieRotatiePatrat::OnKeyPress(int key, int mods)
{
	// add key press event
}

void AnimatieRotatiePatrat::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void AnimatieRotatiePatrat::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void AnimatieRotatiePatrat::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void AnimatieRotatiePatrat::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void AnimatieRotatiePatrat::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void AnimatieRotatiePatrat::OnWindowResize(int width, int height)
{
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)width, 0, height, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	
	
	xc = width / 2;
	yc = height / 2;

	glm::vec3 corner = glm::vec3(0, 0, 0);

	square = Object2D::CreateSquare("square", corner, latura, glm::vec3(1, 0, 0));
	AddMeshToList(square);

}
