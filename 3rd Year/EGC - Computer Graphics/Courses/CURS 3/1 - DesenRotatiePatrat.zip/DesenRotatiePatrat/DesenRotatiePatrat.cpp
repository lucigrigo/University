 #include "DesenRotatiePatrat.h"

#include <vector>
#include <iostream>

#include <Core/Engine.h>
#include "Transform2D.h"
#include "Object2D.h"

using namespace std;

DesenRotatiePatrat::DesenRotatiePatrat()
{
}

DesenRotatiePatrat::~DesenRotatiePatrat()
{
}

void DesenRotatiePatrat::Init()
{
	
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	latura = 100;
	//latura = 50;
	raza = 200;
	xc = resolution.x / 2; yc = resolution.y / 2;
	
	//glm::vec3 corner = glm::vec3(xc+raza - latura / 2, yc - latura / 2, 0);
	glm::vec3 corner = glm::vec3(0, 0, 0);
	square = Object2D::CreateSquare("square", corner, latura, glm::vec3(1, 0, 0));
	AddMeshToList(square);

}

void DesenRotatiePatrat::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(1, 1, 1, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void DesenRotatiePatrat::Update(float deltaTimeSeconds)
{
	glm::ivec2 resolution = window->GetResolution();
	xc = resolution.x / 2;
	yc = resolution.y / 2;

	
	for (int i = 0; i < 10; i++)
	{	
	//	modelMatrix = Transform2D::Translate(xc, yc) *
	//		Transform2D::Rotate(0.628f * i) *
	//		Transform2D::Translate(-xc, -yc)*
	//	    Transform2D::Translate(xc+ raza -latura/2, yc-latura/2); //translateaza patratul in prima pozitie

		modelMatrix = Transform2D::Translate(xc, yc) *
			Transform2D::Rotate(0.628f * i) *
			Transform2D::Translate(raza - latura / 2, - latura / 2 );
		RenderMesh2D(square, shaders["VertexColor"], modelMatrix);
	
		
	}
}

void DesenRotatiePatrat::FrameEnd()
{

}

void DesenRotatiePatrat::OnInputUpdate(float deltaTime, int mods)
{
	
}

void DesenRotatiePatrat::OnKeyPress(int key, int mods)
{
	// add key press event
}

void DesenRotatiePatrat::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void DesenRotatiePatrat::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void DesenRotatiePatrat::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void DesenRotatiePatrat::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void DesenRotatiePatrat::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void DesenRotatiePatrat::OnWindowResize(int width, int height)
{
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)width, 0, height, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();

}
