#include "TransformareaFereastraPoartaPatrate.h"

#include <vector>
#include <iostream>

#include <Core/Engine.h>
#include "Transform2D.h"
#include "Object2DPatrate.h"

using namespace std;

TransformareaFereastraPoartaPatrate::TransformareaFereastraPoartaPatrate()
{
}

TransformareaFereastraPoartaPatrate::~TransformareaFereastraPoartaPatrate()
{
}


void TransformareaFereastraPoartaPatrate::Init()
{
	auto camera = GetSceneCamera();
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

// Seteaza spatiul logic
	logicSpace.x = -5;		// logic x
	logicSpace.y = -5;		// logic y
	logicSpace.width = 10;	// logic width
	logicSpace.height = 10;	// logic height
	
	length = 2.0f;//latura patratului
	raza = 3.6f;
		
	//centrul ferestrei
	cx = logicSpace.x + logicSpace.width / 2;
	cy = logicSpace.y +  logicSpace.height / 2;

	//creaza patratul care se roteste: patrat cu coltul stanga jos in prima pozitie pe cerc
	glm::vec3 corner = glm::vec3(cx - length / 2 + raza , cy - length / 2, 0);  
	Mesh* square = Object2DPatrate::CreateSquare("square", corner, length, glm::vec3(1, 0, 0));
	AddMeshToList(square);

	//// cadrul ferestrei afisat in negru 
	glm::vec3 cornerw = glm::vec3(logicSpace.x, logicSpace.y, 0);
	Mesh* window = Object2DPatrate::CreateSquare("window", cornerw, logicSpace.width, glm::vec3(0, 0, 0));
	AddMeshToList(window);

	uniform = true;//initial transf de vizualizare este uniforma
}

// Calculeaza matricea transformarii de vizualizare 2D 
glm::mat3 TransformareaFereastraPoartaPatrate::VisualizationTransf2D(const LogicSpace & logicSpace, const ViewportSpace & viewSpace)
{
	float sx, sy, tx, ty;
	sx = viewSpace.width / logicSpace.width;
	sy = viewSpace.height / logicSpace.height;
	tx = viewSpace.x - sx * logicSpace.x;
	ty = viewSpace.y - sy * logicSpace.y;

	return glm::transpose(glm::mat3(
		sx, 0.0f, tx,
		0.0f, sy, ty,
		0.0f, 0.0f, 1.0f));
}

// calculeaza matricea transf de vizualizare uniforme
glm::mat3 TransformareaFereastraPoartaPatrate::VisualizationTransf2DUnif(const LogicSpace & logicSpace, const ViewportSpace & viewSpace)
{
	float sx, sy, tx, ty, smin;
	sx = viewSpace.width / logicSpace.width;
	sy = viewSpace.height / logicSpace.height;
	if (sx < sy)
		smin = sx;
	else
		smin = sy;
	tx = viewSpace.x - smin * logicSpace.x + (viewSpace.width - smin * logicSpace.width) / 2;
	ty = viewSpace.y - smin * logicSpace.y + (viewSpace.height - smin * logicSpace.height) / 2;

	return glm::transpose(glm::mat3(
		smin, 0.0f, tx,
		0.0f, smin, ty,
		0.0f, 0.0f, 1.0f));
}

//sterge spatiul portii de afisare cu o culoare specificata
void TransformareaFereastraPoartaPatrate::SetViewportArea(const ViewportSpace & viewSpace, glm::vec3 colorColor, bool clear)
{
	glViewport(viewSpace.x, viewSpace.y, viewSpace.width, viewSpace.height);

	glEnable(GL_SCISSOR_TEST);
	glScissor(viewSpace.x, viewSpace.y, viewSpace.width, viewSpace.height);

	// Clears the color buffer and depth buffer
	glClearColor(colorColor.r, colorColor.g, colorColor.b, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glDisable(GL_SCISSOR_TEST);

	//proiectie ortografica in spatiul portii de afisare
	GetSceneCamera()->SetOrthographic((float)viewSpace.x, (float)(viewSpace.x + viewSpace.width), (float)viewSpace.y, (float)(viewSpace.y + viewSpace.height), 0.1f, 400);
	GetSceneCamera()->Update();
}

void TransformareaFereastraPoartaPatrate::FrameStart()
{
	// Clears the color buffer and depth buffer
	glClearColor(1, 1, 1, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

}


void TransformareaFereastraPoartaPatrate::Update(float deltaTimeSeconds)
{
	glm::ivec2 resolution = window->GetResolution();

	// Seteaza spatiul portii de afisare -  sfertul stanga jos al ferestrei aplicatiei
	viewSpace = ViewportSpace(0, 0, resolution.x / 2, resolution.y / 2);
	SetViewportArea(viewSpace, glm::vec3(1), true);

	if (uniform)
		visMatrix = VisualizationTransf2DUnif(logicSpace, viewSpace);
	else
		visMatrix = VisualizationTransf2D(logicSpace, viewSpace);

	//efectueaza desenul in fereastra (spatiul logic), in culoarea specificata (1,0,1)
	DrawRotatedSquares(visMatrix, glm::vec3(1, 0, 1), 10);
	
	// Seteaza spatiul portii de afisare -  sfertul dreapta jos al ferestrei aplicatiei
	viewSpace = ViewportSpace(resolution.x / 2, 0, resolution.x / 2, resolution.y / 2);
	SetViewportArea(viewSpace, glm::vec3(1), true);

	if (uniform)
		visMatrix = VisualizationTransf2DUnif(logicSpace, viewSpace);
	else
		visMatrix = VisualizationTransf2D(logicSpace, viewSpace);

	//efectueaza desenul in fereastra 
	DrawRotatedSquares(visMatrix, glm::vec3(0, 0, 1), 15);

	// Seteaza spatiul portii de afisare -  sfertul stanga sus al ferestrei aplicatiei
	viewSpace = ViewportSpace(0, resolution.y / 2, resolution.x / 2, resolution.y / 2);
	SetViewportArea(viewSpace, glm::vec3(1), true);
	if (uniform)
		visMatrix = VisualizationTransf2DUnif(logicSpace, viewSpace);
	else
		visMatrix = VisualizationTransf2D(logicSpace, viewSpace);
	DrawRotatedSquares(visMatrix, glm::vec3(1, 0, 0), 20);

	// Seteaza spatiul portii de afisare -  sfertul dreapta sus al ferestrei aplicatiei
	viewSpace = ViewportSpace(resolution.x / 2, resolution.y / 2, resolution.x / 2, resolution.y / 2);
	SetViewportArea(viewSpace, glm::vec3(1), true);
	if (uniform)
		visMatrix = VisualizationTransf2DUnif(logicSpace, viewSpace);
	else
		visMatrix = VisualizationTransf2D(logicSpace, viewSpace);
	DrawRotatedSquares(visMatrix, glm::vec3(0, 0, 0), 25);

}

/*
// Cu decupare la marginile ferestrei/portii de afisare
void TransformareaFereastraPoartaPatrate::Update(float deltaTimeSeconds)
{
	glm::ivec2 resolution = window->GetResolution();

	// Seteaza poarta de afisare
/*
	viewSpace = ViewportSpace(50, 50, resolution.x - 100, resolution.y - 100);
	SetViewportArea(viewSpace, glm::vec3(1), true);

	//deseneaza cadrul ferestrei folosind matricea transf de vizualizare
	visMatrix = VisualizationTransf2D(logicSpace, viewSpace);
	RenderMesh2D(meshes["window"], visMatrix, glm::vec3(0, 0, 0));

	if (uniform)
		visMatrix = VisualizationTransf2DUnif(logicSpace, viewSpace);
	else
		visMatrix = VisualizationTransf2D(logicSpace, viewSpace);
	//deseneaza patratele rotite
	DrawRotatedSquares(visMatrix, glm::vec3(1, 0, 1), 10);

	// se modifica spatiul logic a.i. desenul sa iasa din cadrul ferestrei
	logicSpace.x = -4;		// logic x
	logicSpace.y = -4;		// logic y
	logicSpace.width = 8;	// logic width
	logicSpace.height = 8;	// logic height

//	logicSpace.x = -7;		// logic x
//	logicSpace.y = -7;		// logic y
//	logicSpace.width = 14;	// logic width
//	logicSpace.height = 14;	// logic height

	glm::vec3 cornerw1 = glm::vec3(logicSpace.x+0.01, logicSpace.y+0.01, 0);
	//se creaza cadrul ferestrei
	Mesh* window1 = Object2DPatrate::CreateSquare("window1", cornerw1, logicSpace.width-0.01, glm::vec3(0, 0, 0));
	AddMeshToList(window1);

	viewSpace = ViewportSpace(50, 50, resolution.x - 100, resolution.y - 100);
	SetViewportArea(viewSpace, glm::vec3(1), true);

	//se deseneaza cadrul ferestrei cu negru
	visMatrix = VisualizationTransf2D(logicSpace, viewSpace);
	RenderMesh2D(meshes["window1"], visMatrix, glm::vec3(0, 0, 0));

	if (uniform)
		visMatrix = VisualizationTransf2DUnif(logicSpace, viewSpace);
	else
		visMatrix = VisualizationTransf2D(logicSpace, viewSpace);

	DrawRotatedSquares(visMatrix, glm::vec3(1, 0, 1), 10);

}
*/


void TransformareaFereastraPoartaPatrate::FrameEnd()
{

}
void TransformareaFereastraPoartaPatrate::DrawRotatedSquares(glm::mat3 visMatrix, glm::vec3 color, int iterations)
{
	float delta = 2 * 3.14159 / iterations;
	
	for (int i = 0; i < iterations; i++)
	{
		//transformarea este calculata fata de patratul creat initial: in prima pozitie de pe cerc, in spatiul logic
	   //  (cx - length / 2 + raza, cy - length / 2), unde (cx,cy) este centrul ferestrei logice
		modelMatrix = visMatrix * Transform2D::Translate(cx,cy ) * Transform2D::Rotate(delta * i) * Transform2D::Translate(-cx,-cy);
		
		RenderMesh2D(meshes["square"], modelMatrix, color);
	}

}

void TransformareaFereastraPoartaPatrate::OnInputUpdate(float deltaTime, int mods)
{
	
}

void TransformareaFereastraPoartaPatrate::OnKeyPress(int key, int mods)
{
	if (key == GLFW_KEY_S)
	{
		uniform = !uniform;
	}
}

void TransformareaFereastraPoartaPatrate::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void TransformareaFereastraPoartaPatrate::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void TransformareaFereastraPoartaPatrate::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void TransformareaFereastraPoartaPatrate::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void TransformareaFereastraPoartaPatrate::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}