package com.tema1.goods;

/**
 * Un enum care sa semnifice tipurile de bunuri folosite.
 */
public enum GoodsType {
    Legal,
    Illegal
}
