#include<stdio.h>

/*int varTest=0;

int f1()
{
	varTest+=1;
	return varTest;
}
*/
int main()
{
//	int varTest=5;
//	printf("varTest=%d\n",varTest);
//	f1();
	if(1)
	{
		float varTest=1;
		printf("varTest=%f\n",varTest);
	}
	printf("varTest=%d\n",varTest);
	return 0;
	

}
