#include <stdio.h>
int main()
{
	const int i=3;
	while(i>0)
	{
		printf("%d\n",i);
		i--;
	}
	return 0;
	
}
