/*A programmer heads out to the store. His wife says "while you're out, get some milk."
He never came home.
we're going to implement this using for
*/

#include <stdio.h>

int main()
{
	int out=1;
	
	for(;out==1;)
	{
		printf("i'm still buying milk\n");
	}
	return 0;
}
