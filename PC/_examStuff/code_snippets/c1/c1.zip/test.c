int maxim(int a, int b)
{
	return a>b?a:b;
}
