int maxim(int a, int b);
