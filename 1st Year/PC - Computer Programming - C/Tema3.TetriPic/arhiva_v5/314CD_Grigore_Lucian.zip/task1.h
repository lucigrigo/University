#ifndef TASK1_H
#define TASK1_H
#include "bmp_header.h"

// Functiile gasite in task1.c
void CreateO(bmpFileHeader *, bmpInfoHeader *, char *);
void CreateJ(bmpFileHeader *, bmpInfoHeader *);
void CreateL(bmpFileHeader *, bmpInfoHeader *);
void CreateS(bmpFileHeader *, bmpInfoHeader *, char *);
void CreateZ(bmpFileHeader *, bmpInfoHeader *, char *);
void CreateT(bmpFileHeader *, bmpInfoHeader *);
void CreateI(bmpFileHeader *, bmpInfoHeader *, char *);

#endif
