#ifndef TASKBONUS_H
#define TASKBONUS_H
#include "bmp_header.h"

//  Functia gasita in taskbonus.c
void StartBonus(char **, int, int);

#endif
