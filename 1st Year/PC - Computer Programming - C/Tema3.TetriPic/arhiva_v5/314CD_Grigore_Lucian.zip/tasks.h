#ifndef TASKS_H
#define TASKS_H
#include "bmp_header.h"
#include "utils.h"

//  Functiile gasite in tasks.c
void Task1();
void Task2();
void Task3(bool, bmpPixel **, bmpFileHeader *, bmpInfoHeader *);
void Task4();
void TaskBonus();

#endif
